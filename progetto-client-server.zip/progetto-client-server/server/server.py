import json
import socket
import threading

clients = []
with open("prodotti.json", "r", encoding="utf-8") as file:
  dati = json.load(file)
lista_prodotti = dati["prodotti"]


def gestisci_client(clientsocket, address):
  messaggio = ""
  while not messaggio.endswith("$"):
    try:
      data = clientsocket.recv(1024)
      if data:
        messaggio = data.decode("utf-8")
        print(address, messaggio, flush=True)
        if messaggio == "$" or "CLOSE-CONNECTION" in messaggio:
          break
        if messaggio.startswith("LOGIN:"):
          continue
        if messaggio.startswith("ACQUISTO:"):
          risposta = f"Conferma dal server: {messaggio} registrato!"
          clientsocket.sendall(risposta.encode("utf-8"))
        else:
          # Crea la stringa pulita solo con nome e costo (niente JSON)
          risposta = "\n".join(
              f"{p['nome']}: {p['costo']} €" for p in lista_prodotti
          )
          for c in list(clients):
            try:
              c.sendall(risposta.encode("utf-8"))
            except:
              clients.remove(c)
      else:
        print(address, "disconesso", flush=True)
        break
    except Exception as e:
      print("errore", e, flush=True)
      break
  if clientsocket in clients:
    clients.remove(clientsocket)
  clientsocket.close()


serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#socket.AF_INET usato per dirmi l address family--> ipv4
#socket.SOCK_STREAM --> mi dice che il canale di comunicazione è uno stream di byte e si basa un protocollo tcp

Ip_serversocket = "127.0.0.1"
Porta_serversocket = 5000


#serversocket.bind(()) server per definire la socke, prima l abbiamo creata ora serve definire la porta e l indirizzo ip
#socket.gethostname() mi richiede al sistema operativo l indirizzo ip della socket
#il secondo parametro è la porta

serversocket.bind((Ip_serversocket, Porta_serversocket))
serversocket.listen(5)
print(f"Server in ascolto su {Ip_serversocket}:{Porta_serversocket}...")


# quel numero 5 è il backlog ovvero il numero massimo di client in attesa
while True:
  (clientsocket, address) = serversocket.accept()
  print(address, "connesso", flush=True)
  clients.append(clientsocket)

  # manda subito il json appena il client si connette
  json_iniziale = json.dumps(dati)
  clientsocket.sendall(json_iniziale.encode('utf-8'))
  # nomi_json = ''.join(p['nome'] for p in dati['prodotti'])
  # costo_json = '\n'.join(str(i['costo']) for i in dati['prodotti'])

  # visualizzazione = "\n".join(f"{p['nome']}: {p['costo']} €" for p in dati["prodotti"])
  # clientsocket.sendall(visualizzazione.encode("utf-8"))
  client_thread = threading.Thread(target=gestisci_client, args=(clientsocket, address))
  client_thread.start()
