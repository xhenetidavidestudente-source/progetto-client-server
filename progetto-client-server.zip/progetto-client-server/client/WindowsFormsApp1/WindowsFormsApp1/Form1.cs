﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //se la casella è vuota, non fa nulla e non mostra nessun avviso
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                return;
            }

            try
            {
                TcpClient clientsocket = new TcpClient("127.0.0.1", 5000);
                NetworkStream stream = clientsocket.GetStream();

                int dimensione = 4096;
                byte[] buffer = new byte[dimensione];
                int byteLetti = stream.Read(buffer, 0, buffer.Length);
                string dati_iniziali = Encoding.UTF8.GetString(buffer, 0, byteLetti);

                Form2 secondaSchermata = new Form2(clientsocket, dati_iniziali, textBox1.Text.Trim());
                secondaSchermata.Show();
                this.Hide();
            }
            catch
            {
                //se il server non è raggiungibile, resta sul Form1 senza aprire popup
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
