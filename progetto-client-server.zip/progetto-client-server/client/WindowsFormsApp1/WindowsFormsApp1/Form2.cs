﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        private TcpClient clientsocket;
        private NetworkStream stream;
        private string dati_iniziali;
        private string nomeUtenteAttuale;
        private string messaggioDisconnessione = "CLOSE-CONNECTION$";

        public Form2()
        {
            InitializeComponent();
        }

        public Form2(TcpClient socket, string jsonRicevuto, string nomeUtente)
        {
            InitializeComponent();
            this.clientsocket = socket;
            this.stream = clientsocket.GetStream();
            this.dati_iniziali = jsonRicevuto;
            this.nomeUtenteAttuale = nomeUtente;
            this.Text = "Mercato dell'usato - Utente: " + nomeUtente;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(dati_iniziali)) return;

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            try
            {
                List<Prodotto> listaProdotti = EstraiProdottiDaJson(dati_iniziali);
                foreach (Prodotto p in listaProdotti)
                {
                    MostraProdottoConImmagine(p);
                }
            }
            catch
            {
            }

            Thread thread_ricezione = new Thread(AscoltaServer);
            thread_ricezione.IsBackground = true;
            thread_ricezione.Start();
        }

        private List<Prodotto> EstraiProdottiDaJson(string json)
        {
            List<Prodotto> lista = new List<Prodotto>();
            MatchCollection oggetti = Regex.Matches(json, @"\{[^{}]+\}");

            foreach (Match m in oggetti)
            {
                string blocco = m.Value;
                Prodotto p = new Prodotto();
                p.id = EstraiCampoTesto(blocco, "id");
                p.nome = EstraiCampoTesto(blocco, "nome");
                p.condizioni = EstraiCampoTesto(blocco, "condizioni");
                p.url = EstraiCampoTesto(blocco, "url");

                string costoStr = EstraiCampoNumero(blocco, "costo");
                double.TryParse(costoStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double c);
                p.costo = c;

                if (!string.IsNullOrEmpty(p.nome))
                {
                    lista.Add(p);
                }
            }
            return lista;
        }

        private string EstraiCampoTesto(string testo, string chiave)
        {
            int gruppo = 1;
            Match m = Regex.Match(testo, $"\"{chiave}\"\\s*:\\s*\"([^\"]*)\"");
            return m.Success ? m.Groups[gruppo].Value : "";
        }

        private string EstraiCampoNumero(string testo, string chiave)
        {
            int gruppo = 1;
            Match m = Regex.Match(testo, $"\"{chiave}\"\\s*:\\s*([0-9.]+)");
            return m.Success ? m.Groups[gruppo].Value : "0";
        }

        private void AscoltaServer()
        {
            int dimensione = 4096;
            byte[] buffer = new byte[dimensione];
            while (true)
            {
                try
                {
                    int byteLetti = stream.Read(buffer, 0, buffer.Length);
                    if (byteLetti <= 0)
                    {
                        break;
                    }
                    //riceve la risposta dal server in silenzio senza aprire nessun popup
                }
                catch
                {
                    break;
                }
            }
        }

        private void MostraProdottoConImmagine(Prodotto p)
        {
            Panel scheda = new Panel();
            scheda.Width = 220;
            scheda.Height = 345;
            scheda.BorderStyle = BorderStyle.FixedSingle;
            scheda.Margin = new Padding(10);
            scheda.BackColor = Color.White;

            PictureBox pic = new PictureBox();
            pic.Width = 200;
            pic.Height = 160;
            pic.Location = new Point(10, 10);
            pic.SizeMode = PictureBoxSizeMode.Zoom;

            Label lblNome = new Label();
            lblNome.Text = p.nome;
            lblNome.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblNome.Location = new Point(10, 180);
            lblNome.Size = new Size(200, 45);

            Label lblCosto = new Label();
            lblCosto.Text = p.costo.ToString("0.00") + " €";
            lblCosto.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblCosto.ForeColor = Color.DarkGreen;
            lblCosto.Location = new Point(10, 230);
            lblCosto.AutoSize = true;

            Label lblCond = new Label();
            lblCond.Text = "Condizioni: " + p.condizioni;
            lblCond.ForeColor = Color.DimGray;
            lblCond.Location = new Point(10, 255);
            lblCond.AutoSize = true;

            Button btnAcquista = new Button();
            btnAcquista.Text = "Acquista";
            btnAcquista.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btnAcquista.BackColor = Color.SeaGreen;
            btnAcquista.ForeColor = Color.White;
            btnAcquista.FlatStyle = FlatStyle.Flat;
            btnAcquista.Size = new Size(200, 35);
            btnAcquista.Location = new Point(10, 290);
            btnAcquista.Cursor = Cursors.Hand;

            btnAcquista.Click += (sender, e) =>
            {
                try
                {
                    if (clientsocket != null && clientsocket.Connected)
                    {
                        string messaggioAcquisto = $"ACQUISTO: {nomeUtenteAttuale} ha comprato {p.id} ({p.nome} - {p.costo:0.00} €)";
                        byte[] datiDaInviare = Encoding.UTF8.GetBytes(messaggioAcquisto);
                        stream.Write(datiDaInviare, 0, datiDaInviare.Length);

                        btnAcquista.Text = "Acquistato!";
                        btnAcquista.BackColor = Color.Gray;
                        btnAcquista.Enabled = false;
                    }
                }
                catch
                {
                }
            };

            scheda.Controls.Add(pic);
            scheda.Controls.Add(lblNome);
            scheda.Controls.Add(lblCosto);
            scheda.Controls.Add(lblCond);
            scheda.Controls.Add(btnAcquista);
            flowLayoutPanel1.Controls.Add(scheda);

            try
            {
                pic.LoadAsync(p.url);
            }
            catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            try
            {
                if (clientsocket != null && clientsocket.Connected)
                {
                    byte[] msg = Encoding.UTF8.GetBytes(messaggioDisconnessione);
                    stream.Write(msg, 0, msg.Length);
                    clientsocket.Close();
                }
            }
            catch { }
            Application.Exit();
        }
    }

    public class Prodotto
    {
        public string id { get; set; }
        public string nome { get; set; }
        public double costo { get; set; }
        public string condizioni { get; set; }
        public string url { get; set; }
    }
}
